from rest_framework import viewsets
from rest_framework.decorators import action
from services.serializers import UserSerializer
from services.views import BaseSecurity
from django.contrib.auth.models import User

class UserViewSet(BaseSecurity, viewsets.ModelViewSet):
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = UserSerializer
    
    @action(methods=['post'], detail=False)
    def mensagem(self, request, format=None):
        return Response({"mensagem": f"Olá Mundo, {request.data}",})
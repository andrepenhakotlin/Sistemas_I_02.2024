class BaseSecurity:
    pass
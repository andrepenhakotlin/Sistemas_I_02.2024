from biblioteca.models.exemplo import Exemplo
from django.contrib.auth import get_user_model

User = get_user_model()
User.objects.create_superuser('ifrs', '', 'ifrs')

campus = Exemplo(nome="Script da aula")
campus.full_clean()
campus.save()

print(Exemplo.objects.find_by_nome("IFRS"))

exemplos = Exemplo.objects.all()

for contador, exemplo in enumerate(exemplos):
    print(f"{contador + 1}: {exemplo}")
from django.db import models
from django.db.models import QuerySet

from .base import BaseManager

class ExemploDAO(BaseManager):
    
    def find_by_nome(self, nome: str) -> QuerySet['Exemplo']:
        if isinstance(nome, str):
            consulta = self.filter(nome__contains=nome)
            return consulta
        else:
            raise TypeError('O nome deve ser string')
from .estaticas import *
from .exemplo import *
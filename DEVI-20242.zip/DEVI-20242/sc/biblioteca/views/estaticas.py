from datetime import datetime
from django.shortcuts import render, HttpResponse
from biblioteca.models import Exemplo

def primeira_view(request):
    mensagem = "Bom dia DEV I"
    return HttpResponse(mensagem, status=200)

def saudacao(request):
    agora = datetime.now()
    mensagem = "Olá"
    if 12> agora.hour > 6:
        mensagem = "Bom dia"
    elif 0 < agora.hour <=6:
        mensagem = "Boa madrugada"
    
    completo = f"<html><body><h1>{mensagem.capitalize()} visitante"\
                f"<br />{agora}</h1></body></html>"
    return HttpResponse(completo)


def nome(request, name):
    exemplo = Exemplo.objects.find_by_nome(name)
    context = {'message': name}
    #return HttpResponse(name, status=200)
    return render(request, 'base.html', context)
from .base import *
from django.core.validators import MinLengthValidator, MinValueValidator, MaxValueValidator


class Jogador(models.Model):
    nome = models.CharField(max_length=50, validators=[MinLengthValidator(3)], verbose_name='Nome')
    apelido = models.CharField(max_length=15, verbose_name='Apelido')
    data_nascimento = models.DateField(validators=[], verbose_name='Data de Nascimento')
    numero = models.IntegerField(unique=True, validators=[MinValueValidator(1), MaxValueValidator(99)], verbose_name='Número')
    posicao = models.CharField(max_length=12, validators=[MinLengthValidator(3)], verbose_name='Posição')
    qualidade = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(99)], verbose_name='Qualidade')
    cartoes = models.IntegerField(validators=[MinValueValidator(0), MaxValueValidator(50)], verbose_name='Cartões')
    suspenso = models.BooleanField(verbose_name='Suspenso')
    
    
    
    def __str__(self):
        return self.nome
    
    
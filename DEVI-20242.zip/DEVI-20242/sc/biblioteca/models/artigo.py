from django.db import models
from .reporter import Reporter
from django.core.validators import MinLengthValidator

class Artigo(models.Model):
    titulo = models.CharField(max_length = 100, validators = [MinLengthValidator(5)], verbose_name = 'Título', help_text = 'O título do artigo')
    data_publicacao = models.DateField(verbose_name = 'Data de Publicação', help_text = 'Data de publicação do artigo')
    reporter = models.ForeignKey(Reporter, on_delete = models.SET_NULL, null = True, blank = True)
    
    
    def __str__(self):
        return f"{self.titulo} by {self.reporter.nome if self.reporter is not None else "Anonimo"}" 
    
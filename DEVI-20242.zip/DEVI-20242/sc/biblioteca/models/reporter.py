from django.db import models
from django.core.validators import MinLengthValidator

class Reporter(models.Model):
    
    nome = models.CharField(max_length = 30, validators = [MinLengthValidator(3)], verbose_name = 'Nome Completo', help_text = 'O nome completo do repórter')
    email = models.EmailField()
    cpf = models.CharField(max_length = 11, validators = [MinLengthValidator(11)], verbose_name = 'CPF', help_text = 'O CPF do repórter')
    
    
    def __str__(self):
        return "%s: %s" % (self.nome, self.email)
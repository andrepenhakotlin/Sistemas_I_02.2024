from django.db import models
from .person import Person
from django.core.validators import MinLengthValidator

class Passport(models.Model):
    
    numero = models.CharField(max_length=8, validators = [MinLengthValidator(8)], verbose_name = 'Número Passaporte', help_text = 'Número do Passaporte')
    data_expedicao = models.DateField(verbose_name = 'Data de Expedição')
    data_expiracao = models.DateField(verbose_name = 'Data de Expiração')
    pessoa = models.OneToOneField(Person, on_delete = models.CASCADE, primary_key = True)
    
    
    def __str__(self):
        return self.numero
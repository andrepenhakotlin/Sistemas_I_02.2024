from django.db import models
from django.core.validators import MinLengthValidator


class Person(models.Model):
    nome = models.CharField(max_length=30, validators = [MinLengthValidator(3)], verbose_name = 'Nome', help_text = 'Nome Completo')
    data_nascimento = models.DateField(verbose_name='Data de Nascimento')
    cpf = models.CharField(max_length=11, validators = [MinLengthValidator(11)], verbose_name = 'CPF', help_text = 'CPF')
    
    
    def __str__(self):
        return self.nome
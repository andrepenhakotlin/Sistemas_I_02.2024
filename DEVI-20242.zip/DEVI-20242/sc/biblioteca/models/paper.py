from django.db import models
from .reporter import Reporter
from .magazine import Magazine

class Paper(models.Model):
    titulo = models.CharField(max_length = 100, verbose_name = 'Título', help_text = 'O título do artigo')
    data_publicacao = models.DateField(verbose_name = 'Data de publicação', help_text = 'A data de publicação do artigo')
    reporter = models.ForeignKey(Reporter, on_delete = models.CASCADE)
    magazines = models.ManyToManyField(Magazine)
    
    
    def __str__(self):
        return self.titulo
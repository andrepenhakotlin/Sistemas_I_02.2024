from django.contrib import admin
from biblioteca.models import Exemplo, Carro, Jogador, Person, Passport, Reporter, Artigo, Magazine, Paper



# Register your models here.
admin.site.register((Exemplo, Carro, Jogador, Person, Passport, Reporter, Artigo, Magazine, Paper))

from biblioteca.forms import BaseForm
from biblioteca.models.exemplo import Exemplo

class ExemploForm(BaseForm):
    class Meta:
        model = Exemplo
        fields = '__all__'
from django.urls import include, path
import biblioteca.views as views
from .views.exemplo import ExemploListView, ExemploCreateView, ExemploUpdateView

app_name = 'biblioteca'

urlpatterns = [
    path('teste', views.primeira_view, name="primeira_view"),
    path('saudacao', views.saudacao, name="saudacao"),
    path('<str:name>', views.nome, name="nome"),
    path('exemplo/function/', views.exemplo_list, name="exemplo_function_list"),
    path('exemplo/classe/', ExemploListView.as_view(), name="exemplo_classe_list"),
    path('exemplo/function/read/<int:pk>', views.exemplo_detail, name="exemplo_function_read"),
    path('exemplo/function/delete/<int:exemplo_id>', views.delete, name="exemplo_function_delete"),
    path('exemplo/classe/create', ExemploCreateView.as_view(), name="exemplo_classe_create"),
    path('exemplo/classe/update/<int:pk>', ExemploUpdateView.as_view(), name="exemplo_classe_update"),
    path('services/', include('services.urls')),

]
from django.db.models import TextChoices


class TipoCampeonato(TextChoices):
    PONTOS = "P", "Pontos Corridos"
    ELIMINATORIO = "E", "Eliminatório"
    MISTO = "M", "Classificatório e Eliminatório"

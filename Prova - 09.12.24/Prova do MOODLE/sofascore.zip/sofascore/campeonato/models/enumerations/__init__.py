from .divisao import *
from .resultado import *
from .tipo_campeonato import *

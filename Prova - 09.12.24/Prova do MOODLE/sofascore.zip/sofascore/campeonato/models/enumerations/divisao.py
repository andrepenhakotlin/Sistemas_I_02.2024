from django.db.models import TextChoices


class Divisao(TextChoices):
    A = "A", "Primeira Divisão"
    B = "B", "Segunda Divisão"
    C = "C", "Terceira Divisão"
    U = "U", "Única"

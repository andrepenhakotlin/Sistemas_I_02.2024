from django.db.models import TextChoices


class Resultado(TextChoices):
    VITORIA = "V", "Vitória"
    EMPATE = "E", "Empate"
    DERROTA = "D", "Derrota"

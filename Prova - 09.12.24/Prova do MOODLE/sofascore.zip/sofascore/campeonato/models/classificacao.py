from django.core.validators import MinValueValidator
from django.db import models
from campeonato.models import BaseModel
from campeonato.models.enumerations import Resultado


class Classificacao(BaseModel):
    pontos = models.GeneratedField(
        expression=models.F('vitorias') * 3 + models.F('empates'),
        output_field=models.IntegerField(validators=[MinValueValidator(0)]),
        db_persist=False,
        verbose_name="Pontos",
    )
    vitorias = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Vitórias",
        help_text="Insira a quantidade de vitórias do clube"
    )
    empates = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Empates",
        help_text="Insira a quantidade de empates do clube"
    )
    derrotas = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Derrotas",
        help_text="Insira a quantidade de derrotas do clube"
    )
    gols_marcados = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Gols Pró",
        help_text="Insira a quantidade de gols marcados do clube"
    )
    gols_sofridos = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Gols Contra",
        help_text="Insira a quantidade de gols sofridos do clube"
    )
    saldo_gols = models.GeneratedField(
        expression=models.F('gols_marcados') - models.F('gols_sofridos'),
        output_field=models.IntegerField(validators=[MinValueValidator(0)]),
        db_persist=False,
        verbose_name="Saldo de Gols",
    )

    class Meta:
        verbose_name = "Classificação"
        verbose_name_plural = "Classificações"

    def __str__(self):
        return (f'{self.pontos} - {self.vitorias}V,'
                f' {self.empates}E, {self.derrotas}D,'
                f' {self.gols_marcados}GP, '
                f'{self.gols_sofridos}GC, {self.saldo_gols}SG')

    def atualizar(self, t: 'Time', r: Resultado):
        pass

from campeonato.models import BaseModel


class Clube(BaseModel):
    pass

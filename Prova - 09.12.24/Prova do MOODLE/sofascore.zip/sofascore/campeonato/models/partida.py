from datetime import date

from django.core.validators import MinValueValidator
from django.db import models
from campeonato.models import BaseModel


class Partida(BaseModel):
    data = models.DateField(
        default=date.today(),
        verbose_name="Data da Partida",
        help_text="Selecione a data da Partida"
    )
    gols_mandante = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Gols Mandante",
        help_text="Insira a quantidade de gols do clube mandante"
    )
    gols_visitante = models.IntegerField(
        default=0, validators=[MinValueValidator(0)],
        verbose_name="Gols Visitante",
        help_text="Insira a quantidade de gols do clube visitante"
    )
    wo = models.BooleanField(
        default=False, verbose_name="WO",
        help_text="Informe se ocorreu WO"
    )

    def __str__(self):
        return (f'{self.data.strftime(format="%d/%m/%Y")}: '
                f'{self.gols_mandante} x {self.gols_visitante}')
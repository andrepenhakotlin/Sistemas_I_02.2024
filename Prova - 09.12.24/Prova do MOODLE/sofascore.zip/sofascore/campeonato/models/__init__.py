from .base import *
from .clube import *
from .campeonato import *
from .classificacao import *
from .partida import *

from campeonato.models import BaseModel


class Campeonato(BaseModel):
    pass

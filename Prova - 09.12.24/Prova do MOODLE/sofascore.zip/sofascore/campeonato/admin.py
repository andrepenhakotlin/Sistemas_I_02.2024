from django.contrib import admin
from campeonato.models import *

admin.site.register((Classificacao, Partida))
